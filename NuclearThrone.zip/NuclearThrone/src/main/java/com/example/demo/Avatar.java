package com.example.demo;

import javafx.geometry.BoundingBox;
import javafx.geometry.Bounds;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

import java.util.Objects;

public class Avatar extends Drawing implements Runnable {
    private final Image[] stationary;
    private final Image[] movement;
    private int frame = 0;
    private boolean isMoving;
    private boolean isFacingRight = true;
    private int lives;
    private boolean invulnerability;
    private Weapon weapon;

    public Avatar() {

        pos.setX(100);
        pos.setY(100);

        lives = 5;

        stationary = new Image[2];
        for (int i = 1; i <= 2; i++) {
            String uri = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("staticPlayer/player" + i + ".png")).getPath();
            stationary[i - 1] = new Image(uri);
        }

        movement = new Image[2];
        for (int i = 1; i <= 2; i++) {
            String uri = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("movementPlayer/player" + i + ".png")).getPath();
            movement[i - 1] = new Image(uri);
        }
    }

    @Override
    public void draw(GraphicsContext gc) {
        if (isFacingRight)
            gc.drawImage(
                    isMoving ? movement[frame] : stationary[frame], pos.getX() - 25, pos.getY() - 25, 50, 50);
        else
            gc.drawImage(isMoving ? movement[frame] : stationary[frame], pos.getX() + 25, pos.getY() - 25, -50, 50);
    }

    private boolean isAlive = true;

    @Override
    public void run() {
        while (isAlive) {
            frame = (frame + 1) % 4;
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    public boolean avatarWallCollision(Wall wall) {
        Bounds avatarBounds = calculateAreaLimits();
        Bounds wallBounds = wall.getRectangle().getBoundsInParent();
        return avatarBounds.intersects(wallBounds);
    }

    public double getOverlapX(Wall wall) {
        Bounds avatarArea = calculateAreaLimits();
        Bounds wallArea = wall.getRectangle().getBoundsInParent();

        if (avatarArea.getMinX() < wallArea.getMinX()) {
            return avatarArea.getMaxX() - wallArea.getMinX();
        } else {
            return wallArea.getMaxX() - avatarArea.getMinX();
        }
    }

    public double getOverlapY(Wall wall) {
        Bounds avatarArea = calculateAreaLimits();
        Bounds wallArea = wall.getRectangle().getBoundsInParent();

        if (avatarArea.getMinY() < wallArea.getMinY()) {
            return avatarArea.getMaxY() - wallArea.getMinY();
        } else {
            return wallArea.getMaxY() - avatarArea.getMinY();
        }
    }

    public int getLives() {
        return lives;
    }

    public void setLives(int lives) {
        this.lives = lives;
    }

    public void setMoving(boolean moving) {
        isMoving = moving;
    }

    public void setFacingRight(boolean facingRight) {
        isFacingRight = facingRight;
    }

    public boolean isInvulnerability() {
        return invulnerability;
    }

    public void setInvulnerability(boolean invulnerability) {
        this.invulnerability = invulnerability;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }

    public Bounds calculateAreaLimits() {
        return new BoundingBox(pos.getX() - 25, pos.getY() - 25, 50, 50);
    }

}
