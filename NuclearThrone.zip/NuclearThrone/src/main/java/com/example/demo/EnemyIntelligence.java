package com.example.demo;

import javafx.geometry.BoundingBox;
import javafx.geometry.Bounds;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

import java.util.Objects;

public class EnemyIntelligence extends Enemy {
    private final Image[] staticEnemy;
    private final Image[] movementEnemy;
    private int frame = 0;
    private boolean isMoving = false;
    private int lives;

    public EnemyIntelligence(Vector pos) {
        super(pos);
        staticEnemy = new Image[2];
        lives = 3;
        for (int i = 1; i <= 2; i++) {
            String uri = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("staticEnemy/enemy" + i + ".png")).getPath();
            staticEnemy[i - 1] = new Image(uri);
        }

        movementEnemy = new Image[8];
        for (int i = 1; i <= 8; i++) {
            String uri = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("movementEnemy/enemy" + i + ".png")).getPath();
            movementEnemy[i - 1] = new Image(uri);
        }
    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.drawImage(isMoving ? movementEnemy[frame] : staticEnemy[frame], pos.getX() - 25, pos.getY() - 25, 50, 50);
    }

    public boolean calculateEnemyCollisionsWithWall(Wall wall) {
        Bounds enemyBounds = calculateEnemyCollisionsWithWall();
        Bounds wallBounds = wall.getRectangle().getBoundsInParent();
        return enemyBounds.intersects(wallBounds);
    }

    public double getOverlapXBetweenAvatarAndWall(Wall wall) {
        Bounds enemyArea = calculateEnemyCollisionsWithWall();
        Bounds wallArea = wall.getRectangle().getBoundsInParent();

        if (enemyArea.getMinX() < wallArea.getMinX()) {
            return enemyArea.getMaxX() - wallArea.getMinX();
        } else {
            return wallArea.getMaxX() - enemyArea.getMinX();
        }
    }

    public double getOverlapYBetweenAvatarAndWall(Wall wall) {
        Bounds enemyArea = calculateEnemyCollisionsWithWall();
        Bounds wallArea = wall.getRectangle().getBoundsInParent();

        if (enemyArea.getMinY() < wallArea.getMinY()) {
            return enemyArea.getMaxY() - wallArea.getMinY();
        } else {
            return wallArea.getMaxY() - enemyArea.getMinY();
        }
    }

    public boolean isAlive = true;

    @Override
    public void run() {

        while (isAlive) {
            isMoving = true;
            frame = (frame + 1) % 6;

            pos.setY(pos.getY());
            pos.setX(pos.getX());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public int getLives() {
        return lives;
    }

    public void setLives(int lives) {
        this.lives = lives;
    }
    public Bounds calculateEnemyCollisionsWithWall() {
        return new BoundingBox(pos.getX() - 25, pos.getY() - 25, 50, 50);
    }
}
