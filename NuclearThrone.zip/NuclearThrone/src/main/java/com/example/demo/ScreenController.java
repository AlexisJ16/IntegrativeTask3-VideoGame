package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ScreenController {

    @FXML
    private Button resetBtn;

    @FXML
    private Button exitBtn;

    @FXML
    private Button waitingBtn;

    @FXML
    private Button startBtn;

    @FXML
    private Button waitingBtn2;

    @FXML
    public void resetGame(ActionEvent event) {
        Stage stage = (Stage) this.resetBtn.getScene().getWindow();
        stage.close();
        HelloApplication.openWindow("Startup_Scene-view.fxml");
    }

    @FXML
    public void exitGame(ActionEvent event) {
        Stage stage = (Stage) this.exitBtn.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void gameOver(ActionEvent event) {
        Stage stage = (Stage) this.waitingBtn.getScene().getWindow();
        stage.close();
        HelloApplication.openWindow("exitScreen-view.fxml");
    }

    @FXML
    public void startGame(ActionEvent event) {
        Stage stage = (Stage) this.startBtn.getScene().getWindow();
        stage.close();
        HelloApplication.openWindow("hello-view.fxml");
    }

    @FXML
    public void win(ActionEvent event) {
        Stage stage = (Stage) this.waitingBtn2.getScene().getWindow();
        stage.close();
        HelloApplication.openWindow("exitScreen-view.fxml");
    }

}
