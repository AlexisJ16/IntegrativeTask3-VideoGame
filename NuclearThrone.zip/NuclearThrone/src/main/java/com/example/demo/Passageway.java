package com.example.demo;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

import java.util.Objects;

public class Passageway extends Drawing implements Runnable {

    private int x = 500, y = 500;
    private int frame = 0;
    private Image[] passagewayImages;

    String uri1 = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("passageway/portal0.png")).getPath();
    String uri2 = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("passageway/portal1.png")).getPath();
    String uri3 = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("passageway/portal2.png")).getPath();
    String uri4 = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("passageway/portal3.png")).getPath();
    String uri5 = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("passageway/portal4.png")).getPath();
    String uri6 = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("passageway/portal5.png")).getPath();


    public Passageway() {
        // Cargar las imágenes del pasaje
        passagewayImages = new Image[6];
        passagewayImages[0] = new Image(uri1);
        passagewayImages[1] = new Image(uri2);
        passagewayImages[2] = new Image(uri3);
        passagewayImages[3] = new Image(uri4);
        passagewayImages[4] = new Image(uri5);
        passagewayImages[5] = new Image(uri6);

    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.drawImage(frame >= 0 && frame <= 6 ? passagewayImages[frame] : passagewayImages[0], x, y, 80, 80);
    }

    public boolean isAlive = true;

    @Override
    public void run() {
        while (isAlive) {
            frame = (frame + 1) % 6;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

}
