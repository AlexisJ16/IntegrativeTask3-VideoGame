package com.example.demo;

import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Level {

    private int id;
    private Color color;
    private Image background;
    private List<Enemy> enemies;
    private List<Wall> walls;
    private Weapon weapon;

    public Level(int id) {
        this.id = id;
        String[] backgrounds = {
                "file:" + Objects.requireNonNull(HelloApplication.class.getResource("background/Fondo1.png")).getPath(),
                "file:" + Objects.requireNonNull(HelloApplication.class.getResource("background/fondo2.png")).getPath(),
                "file:" + Objects.requireNonNull(HelloApplication.class.getResource("background/fondos3.png")).getPath()
        };
        background = new Image(backgrounds[id]);
        enemies = new ArrayList<>();
        walls = new ArrayList<>();
    }

    public void generateMap(Canvas canvas, int index) {
        walls = new ArrayList<>();

        addVerticalWall(canvas, index, 500, 200, 350, 50);
        addHorizontalWall(canvas, index, 400, 100, 600, 50);
        addVerticalWall(canvas, index, 800, 0, 250, 50);
        addVerticalWall(canvas, index, 750, 550, (int) canvas.getHeight(), 50);
        addVerticalWall(canvas, index, 150, 550, (int) canvas.getHeight(), 50);
        addHorizontalWall(canvas, index, 950, 150, 1000, 50);
        addHorizontalWall(canvas, index, 1000, 500, (int) canvas.getWidth(), 50);
        addHorizontalWall(canvas, index, 400, 500, 450, 50);
        addVerticalWall(canvas, index, 300, 450, 450, 50);
        addVerticalWall(canvas, index, 200, 200, 400, 50);
        addVerticalWall(canvas, index, 150, 0, 100, 50);
        addVerticalWall(canvas, index, 150, 200, 250, 50);
        addVerticalWall(canvas, index, 650, 200, 400, 50);
        addVerticalWall(canvas, index, 550, 55, 350, 50);
        addHorizontalWall(canvas, index, 750, 350, 1000, 50);
    }

    private void addVerticalWall(Canvas canvas, int index, int x, int yStart, int yEnd, int step) {
        for (int i = yStart; i <= yEnd; i += step) {
            Wall wall = new Wall(x, i, canvas, index);
            walls.add(wall);
        }
    }

    private void addHorizontalWall(Canvas canvas, int index, int xStart, int y, int xEnd, int step) {
        for (int i = xStart; i <= xEnd; i += step) {
            Wall wall = new Wall(i, y, canvas, index);
            walls.add(wall);
        }
    }

    public int getId() {
        return id;
    }


    public Image getBackground() {
        return background;
    }


    public void setColor(Color color) {
        this.color = color;
    }

    public List<Enemy> getEnemies() {
        return enemies;
    }


    public List<Wall> getWalls() {
        return walls;
    }


    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }
}
