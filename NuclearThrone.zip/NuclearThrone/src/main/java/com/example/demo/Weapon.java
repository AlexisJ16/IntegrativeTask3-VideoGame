package com.example.demo;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.Objects;

public class Weapon extends Drawing {

    private int x = 30, y = 120;
    private Image weaponDraw;
    private ArrayList<Bullet> bullets;
    private int ammo;
    private int maxAmmo;
    private int currentLevelOnAvatar; // Nivel actual
    private boolean collected;

    String uri1 = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("weapon/gun1.png")).getPath();
    String uri2 = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("weapon/gun2.png")).getPath();
    String uri3 = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("weapon/gun3.png")).getPath();

    public Weapon(int currentLevelOnAvatar) {
        switch (currentLevelOnAvatar) {
            case 0 -> weaponDraw = new Image(uri1);
            case 1 -> weaponDraw = new Image(uri2);
            case 2 -> weaponDraw = new Image(uri3);
        }
        this.currentLevelOnAvatar = currentLevelOnAvatar;
        this.maxAmmo = 5;
        this.ammo = 5;
        this.collected = false;
        bullets = new ArrayList<>();
    }

    public void shoot(Vector posPlayer, Vector diff) {
        Bullet bullet = new Bullet(posPlayer, diff);
        bullet.setColor(colorBullet());
        bullets.add(bullet);
        ammo--;
    }

    private Color colorBullet() {
        switch (currentLevelOnAvatar) {
            case 0 -> {
                return Color.BLACK;
            }
            case 1 -> {
                return Color.GREENYELLOW;
            }
            case 2 -> {
                return Color.GOLD;
            }
            default -> {
                return Color.INDIANRED;
            }
        }
    }

    public void reload() {
        new Thread(() -> {
            while (ammo < maxAmmo) {
                ammo++;
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.drawImage(weaponDraw, x, y, 30, 25);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Image getWeaponDraw() {
        return weaponDraw;
    }

    public int getAmmo() {
        return ammo;
    }

    public boolean isCollected() {
        return collected;
    }

    public void setCollected(boolean collected) {
        this.collected = collected;
    }

    public ArrayList<Bullet> getBullets() {
        return bullets;
    }

}