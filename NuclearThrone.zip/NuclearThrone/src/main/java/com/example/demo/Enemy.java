package com.example.demo;

import javafx.scene.canvas.GraphicsContext;

public abstract class Enemy extends Drawing implements Runnable {
    private int lives;

    public Enemy(Vector pos) {
        this.pos = pos;
    }

    @Override
    public void draw(GraphicsContext gc) {

    }

    @Override
    public void run() {
    }

    public boolean calculateEnemyCollisionsWithWall(Wall wall) { return false; }

    public double getOverlapXBetweenAvatarAndWall(Wall wall) {
        return 0;
    }

    public double getOverlapYBetweenAvatarAndWall(Wall wall) {
        return 0;
    }

    public int getLives() {
        return lives;
    }

    public void setLives(int lives) {
        this.lives = lives;
    }

}
