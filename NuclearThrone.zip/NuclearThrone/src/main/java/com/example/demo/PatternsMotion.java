package com.example.demo;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

import java.util.Objects;

public class PatternsMotion extends Enemy {
    private final Image[] staticEnemy;
    private final Image[] movementEnemy;
    private int frame = 0;
    private boolean isMoving = false;
    private int movementDirectionX = 1;
    private int movementDirectionY = 1;
    private final double initialX;
    private final double initialY;
    private int lives;

    public PatternsMotion(Vector pos) {
        super(pos);
        lives = 3;
        initialX = pos.getX();
        initialY = pos.getY();
        staticEnemy = new Image[2];
        for (int i = 1; i <= 2; i++) {
            String uri = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("staticEnemy/enemy" + i + ".png")).getPath();
            staticEnemy[i - 1] = new Image(uri);
        }

        movementEnemy = new Image[8];
        for (int i = 1; i <= 8; i++) {
            String uri = "file:" + Objects.requireNonNull(HelloApplication.class.getResource("movementEnemy/enemy" + i + ".png")).getPath();
            movementEnemy[i - 1] = new Image(uri);
        }
    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.drawImage(
                isMoving ? movementEnemy[frame] : staticEnemy[frame], pos.getX() - 25, pos.getY() - 25, 50, 50);
    }

    public boolean isAlive = true;

    @Override
    public void run() {
        while (isAlive) {
            isMoving = true;
            frame = (frame + 1) % 6;

            double distanceX = Math.abs(pos.getX() - initialX);

            double movementLimit = 100;
            if (distanceX >= movementLimit) {
                movementDirectionX *= -1;
            }

            pos.setX(pos.getX() + (movementDirectionX * 1));

            double distanceY = Math.abs(pos.getY() - initialY);

            if (distanceY >= movementLimit) {
                movementDirectionY *= -1;
            }
            pos.setY(pos.getY() + (movementDirectionY * 1));

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public int getLives() {
        return lives;
    }

    @Override
    public void setLives(int lives) {
        this.lives = lives;
    }
}
